const mongoose = require("mongoose");
const express = require("express");
const Schema = mongoose.Schema;
const app = express();
const jsonParser = express.json();

const playerScheme = new Schema(
    {
        name: String,
        lastname: String,
        age: Number,
        team: String,
    },
    { versionKey: false }
);
const Player = mongoose.model("Player", playerScheme);

app.use(express.static(__dirname + "/public"));

mongoose.connect("mongodb://localhost:27017/playersdb", { useUnifiedTopology: true, useNewUrlParser: true, useFindAndModify: false }, function (err) {
    if (err) return console.log(err);
    app.listen(3000, function () {
        console.log("Сервер запущено...");
    });
});

app.get("/api/players", function (req, res) {
    Player.find({}, function (err, players) {

        if (err) return console.log(err);
        res.send(players)
    });

});
app.get("/api/players/:id", function (req, res) {
    const id = req.params.id;
    Player.findOne({ _id: id }, function (err, players) {

        if (err) return console.log(err);
        res.send(players);
    });
});

app.post("/api/players", jsonParser, function (req, res) {

    if (!req.body) return res.sendStatus(400);

    const playerName = req.body.name;
    const playerLastName = req.body.lastname;
    const playerAge = req.body.age;
    const playerTeam = req.body.team;

    const player = new Player({ name: playerName, lastname: playerLastName, age: playerAge, team: playerTeam });

    player.save(function (err) {
        if (err) return console.log(err);
        res.send(player);
    });
});

app.delete("/api/players/:id", function (req, res) {
    const id = req.params.id;
    Player.findByIdAndDelete(id, function (err, player) {

        if (err) return console.log(err);
        res.send(player);
    });
});

app.put("/api/players", jsonParser, function (req, res) {

    if (!req.body) return res.sendStatus(400);
    const id = req.body.id;
    const playerName = req.body.name;
    const playerLastName = req.body.lastname;
    const playerAge = req.body.age;
    const playerTeam = req.body.team;

    const newPlayer = { age: playerAge, lastname: playerLastName, name: playerName, team: playerTeam };

    Player.findOneAndUpdate({ _id: id }, newPlayer, { new: true }, function (err, player) {
        if (err) return console.log(err);
        res.send(player);
    });
});
